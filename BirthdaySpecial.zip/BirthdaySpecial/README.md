# Happy Birthday

Website - [Happy Birthday](https://rishabh04-02.github.io/happy-birthday/)

An easy to deploy, Happy Birthday animation design TEMPLATE.

View Deployments [here](https://github.com/Rishabh04-02/happy-birthday/deployments)
